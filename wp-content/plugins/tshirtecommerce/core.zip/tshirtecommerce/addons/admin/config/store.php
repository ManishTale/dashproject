<div style="display: none;">
<?php echo displayRadio('merge_cliparts', $data['settings'], 'merge_cliparts', 0); ?>
</div>