<?php 
 // @deprecated
?>