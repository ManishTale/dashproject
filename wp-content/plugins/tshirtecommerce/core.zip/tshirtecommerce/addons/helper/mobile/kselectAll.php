<?php
$addons = $GLOBALS['addons'];
?>
<li>
	<button type="button" class="btn btn-sm btn-none" onclick="design.selectAll()">
		<i class="glyph-icon flaticon-folder"></i> <small><?php echo $addons->__('addon_select_all_button_title'); ?></small>
	</button>
</li>